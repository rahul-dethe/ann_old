#!/bin/bash

# Define Miniconda installer and target directory
MINICONDA_INSTALLER="Miniconda3-latest-Linux-x86_64.sh"
MINICONDA_URL="https://repo.anaconda.com/miniconda/$MINICONDA_INSTALLER"
MINICONDA_INSTALL_DIR="$HOME/miniconda"

# Download Miniconda installer
echo "Downloading Miniconda installer..."
wget $MINICONDA_URL -O $MINICONDA_INSTALLER

# Run the Miniconda installer
echo "Installing Miniconda..."
bash $MINICONDA_INSTALLER -b -p $MINICONDA_INSTALL_DIR

# Initialize Conda
echo "Initializing Conda..."
source $MINICONDA_INSTALL_DIR/bin/activate

# Create and activate the Conda environment
echo "Creating Conda environment from environment.yml..."
conda env create -f ann-ci.yml

echo "Activating the environment..."
source $MINICONDA_INSTALL_DIR/bin/activate ann-ci

rm $MINICONDA_INSTALLER

echo "Conda environment setup complete."
